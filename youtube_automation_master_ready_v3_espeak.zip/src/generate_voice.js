const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function textToSpeechEspeak(text, outPath){
  const dir = path.dirname(outPath);
  if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const speed = 150;
  const safeText = text.replace(/"/g, '\"').replace(/`/g, "'");
  const cmd = `espeak -v en-us -s ${speed} --stdout "${safeText}" > "${outPath}"`;
  execSync(cmd, { stdio: 'inherit', shell: true });
  return outPath;
}

module.exports = { textToSpeechEspeak };
