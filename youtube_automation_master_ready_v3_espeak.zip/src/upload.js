const fs = require('fs');
const {google} = require('googleapis');

async function uploadVideo({filePath, title, description, tags, thumbnailPath}){
  const clientId = process.env.YT_CLIENT_ID;
  const clientSecret = process.env.YT_CLIENT_SECRET;
  const refreshToken = process.env.YT_REFRESH_TOKEN;
  if(!clientId || !clientSecret || !refreshToken) throw new Error('Missing YouTube OAuth secrets');

  const oauth2Client = new google.auth.OAuth2(clientId, clientSecret);
  oauth2Client.setCredentials({ refresh_token: refreshToken });

  const youtube = google.youtube({version:'v3', auth: oauth2Client});

  const res = await youtube.videos.insert({
    part: ['snippet','status'],
    requestBody: {
      snippet: {
        title: title,
        description: description,
        tags: tags,
      },
      status: {
        privacyStatus: 'public'
      }
    },
    media: {
      body: fs.createReadStream(filePath)
    }
  });

  const videoId = res.data.id;
  if(thumbnailPath && fs.existsSync(thumbnailPath)){
    await youtube.thumbnails.set({
      videoId,
      media: {
        body: fs.createReadStream(thumbnailPath)
      }
    });
  }

  return { videoId, raw: res.data };
}

module.exports = { uploadVideo };
