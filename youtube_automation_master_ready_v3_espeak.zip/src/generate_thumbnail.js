const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

function makeThumbnailFromImage(imagePath, outPath, title){
  const dir = path.dirname(outPath);
  if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const safeTitle = title.replace(/"/g, '\"').slice(0,60);
  const cmd = `convert "${imagePath}" -resize 1280x720^ -gravity center -extent 1280x720 -font DejaVu-Sans -pointsize 64 -fill white -stroke black -strokewidth 2 -gravity south -annotate +0+60 "${safeTitle}" "${outPath}"`;
  execSync(cmd, { stdio: 'inherit', shell: true });
  return outPath;
}

module.exports = { makeThumbnailFromImage };
