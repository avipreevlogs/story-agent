const { OpenAIApi, Configuration } = require('openai');
const prompts = require('./prompts');
const conf = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const client = new OpenAIApi(conf);

async function generateSeed(){
  const prompt = prompts.seedPrompt;
  const resp = await client.createChatCompletion({
    model: 'gpt-4o-mini',
    messages: [{role:'user', content: prompt}],
    max_tokens: 200,
    temperature: 0.9
  });
  const txt = resp.data.choices[0].message.content.trim();
  try{
    const arr = JSON.parse(txt);
    if(Array.isArray(arr) && arr.length>0) return arr[0];
  }catch(e){
    return txt.split('\n').map(l=>l.trim()).filter(Boolean)[0];
  }
}

async function generateStoryForSeed(seed){
  const prompt = prompts.storyPrompt(seed);
  const resp = await client.createChatCompletion({
    model: 'gpt-4o-mini',
    messages: [{role:'user', content: prompt}],
    max_tokens: 700,
    temperature: 0.9
  });
  return resp.data.choices[0].message.content.trim();
}

module.exports = { generateSeed, generateStoryForSeed };
