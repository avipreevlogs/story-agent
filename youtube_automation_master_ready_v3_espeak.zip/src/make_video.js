const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

function getAudioDuration(audioPath){
  try{
    const cmd = `ffprobe -v error -show_entries format=duration -of csv=p=0 "${audioPath}"`;
    const out = execSync(cmd, { encoding: 'utf8', shell: true }).trim();
    return parseFloat(out) || 0;
  }catch(e){
    return 0;
  }
}

function makeVideoFromImageAndAudio(imagePath, audioPath, outPath){
  const dir = path.dirname(outPath);
  if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const duration = getAudioDuration(audioPath) || 6;
  const cmd = `ffmpeg -y -loop 1 -i "${imagePath}" -i "${audioPath}" -c:v libx264 -t ${duration} -pix_fmt yuv420p -c:a aac -b:a 192k -shortest "${outPath}"`;
  execSync(cmd, { stdio: 'inherit', shell: true });
  return outPath;
}

module.exports = { makeVideoFromImageAndAudio };
