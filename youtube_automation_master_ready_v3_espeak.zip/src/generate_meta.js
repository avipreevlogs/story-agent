const { OpenAIApi, Configuration } = require('openai');
const prompts = require('./prompts');
const conf = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const client = new OpenAIApi(conf);

async function generateMetaFromSeed(seed){
  const prompt = prompts.metaPrompt(seed);
  const resp = await client.createChatCompletion({
    model: 'gpt-4o-mini',
    messages: [{role:'user', content: prompt}],
    max_tokens: 400,
    temperature: 0.8
  });
  const text = resp.data.choices[0].message.content.trim();
  try{
    const parsed = JSON.parse(text);
    return {
      title: parsed.title || parsed.Title || seed,
      description: parsed.description || parsed.Description || '',
      tags: parsed.tags || parsed.Tags || []
    };
  }catch(e){
    const lines = text.split('\n').map(l=>l.trim()).filter(Boolean);
    return { title: lines[0]||seed, description: lines.slice(1,3).join(' '), tags: [] };
  }
}

module.exports = { generateMetaFromSeed };
