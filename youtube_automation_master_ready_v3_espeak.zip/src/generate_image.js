const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function createSlideImage(title, outPath){
  const dir = path.dirname(outPath);
  if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const safeTitle = title.replace(/"/g, '\"');
  const cmd = `convert -size 1280x720 gradient: -gravity center -pointsize 48 -font DejaVu-Sans -fill white -stroke black -strokewidth 2 -annotate +0+0 "${safeTitle}" "${outPath}"`;
  execSync(cmd, { stdio: 'inherit', shell: true });
  return outPath;
}

module.exports = { createSlideImage };
