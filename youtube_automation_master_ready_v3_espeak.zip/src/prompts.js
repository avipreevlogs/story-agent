module.exports = {
  storyPrompt: (seed) => `Write a short, original, engaging YouTube script (around 120-220 words) for a quick narrated video based on this seed/topic: "${seed}". Keep it punchy, divided into short sentences suitable for voiceover, include a suggested 1-2 line hook for the beginning. Return only the script text.`,
  metaPrompt: (titleSeed) => `Create a viral YouTube video title (<=70 chars), a 2-3 sentence description optimized for engagement, and an array of 8 short tags for the video about: "${titleSeed}". Return a JSON object with keys: title, description, tags.`,
  seedPrompt: `Provide 1 short, distinct seed idea/topic suitable for a short narrated video (2-6 words). Return a JSON array with a single item.`
};
